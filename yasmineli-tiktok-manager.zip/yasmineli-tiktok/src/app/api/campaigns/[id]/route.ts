// src/app/api/campaigns/[id]/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { updateCampaign, deleteCampaign, getCampaignById } from '@/lib/db';
import { tiktokClient } from '@/lib/tiktok-api';

export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
  const campaign = getCampaignById(params.id);
  if (!campaign) return NextResponse.json({ success: false, error: 'Bulunamadı' }, { status: 404 });
  return NextResponse.json({ success: true, data: campaign });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await req.json();
    const updated = updateCampaign(params.id, body);
    if (!updated) return NextResponse.json({ success: false, error: 'Bulunamadı' }, { status: 404 });

    // Sync status to TikTok if campaign is connected
    if (updated.tiktok_campaign_id && body.status) {
      const opMap: Record<string, 'ENABLE' | 'DISABLE'> = {
        active: 'ENABLE',
        paused: 'DISABLE',
      };
      const op = opMap[body.status];
      if (op) {
        try {
          await tiktokClient.updateCampaignStatus(updated.tiktok_campaign_id, op);
        } catch {
          console.warn('TikTok status sync failed (demo mode)');
        }
      }
    }

    return NextResponse.json({ success: true, data: updated });
  } catch (err) {
    return NextResponse.json({ success: false, error: (err as Error).message }, { status: 500 });
  }
}

export async function DELETE(_: NextRequest, { params }: { params: { id: string } }) {
  const campaign = getCampaignById(params.id);
  if (!campaign) return NextResponse.json({ success: false, error: 'Bulunamadı' }, { status: 404 });

  if (campaign.tiktok_campaign_id) {
    try {
      await tiktokClient.updateCampaignStatus(campaign.tiktok_campaign_id, 'DELETE');
    } catch {
      console.warn('TikTok delete sync failed (demo mode)');
    }
  }

  deleteCampaign(params.id);
  return NextResponse.json({ success: true });
}
