// src/app/api/campaigns/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getCampaigns, createCampaign } from '@/lib/db';
import { tiktokClient } from '@/lib/tiktok-api';

export async function GET() {
  try {
    const campaigns = getCampaigns();
    return NextResponse.json({ success: true, data: campaigns });
  } catch (err) {
    return NextResponse.json({ success: false, error: (err as Error).message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, objective, ad_type, markets, budget_daily, budget_total, start_date, end_date } = body;

    if (!name || !markets?.length || !budget_daily) {
      return NextResponse.json({ success: false, error: 'Eksik alanlar: name, markets, budget_daily zorunlu' }, { status: 400 });
    }

    // Create in local DB
    const campaign = createCampaign({
      name,
      objective: objective || 'REACH',
      ad_type: ad_type || 'In-Feed Ads',
      markets,
      budget_daily: Number(budget_daily),
      budget_total: budget_total ? Number(budget_total) : undefined,
      status: 'scheduled',
      start_date: start_date || new Date().toISOString().split('T')[0],
      end_date,
    });

    // Try to create on TikTok API (if connected)
    const settings = await import('@/lib/db').then(m => m.getSettings());
    if (settings.tiktok_connected && process.env.TIKTOK_ACCESS_TOKEN !== 'your_access_token_here') {
      try {
        const tikResult = await tiktokClient.createCampaign({
          name,
          objective: objective || 'REACH',
          budget: Number(budget_daily),
          budget_mode: 'BUDGET_MODE_DAY',
        });
        await import('@/lib/db').then(m =>
          m.updateCampaign(campaign.id, { tiktok_campaign_id: tikResult.campaign_id, status: 'active' })
        );
      } catch (apiErr) {
        console.warn('TikTok API create failed (demo mode):', (apiErr as Error).message);
      }
    }

    return NextResponse.json({ success: true, data: campaign }, { status: 201 });
  } catch (err) {
    return NextResponse.json({ success: false, error: (err as Error).message }, { status: 500 });
  }
}
