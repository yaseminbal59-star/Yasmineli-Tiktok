// src/app/api/tiktok/callback/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { tiktokClient } from '@/lib/tiktok-api';
import { updateSettings } from '@/lib/db';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const code = searchParams.get('auth_code') || searchParams.get('code');
  const error = searchParams.get('error');

  if (error) {
    return NextResponse.redirect(
      `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/?error=tiktok_auth_failed`
    );
  }

  if (!code) {
    return NextResponse.redirect(
      `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/?error=no_code`
    );
  }

  try {
    const tokens = await tiktokClient.exchangeCode(code);

    // Save to settings
    updateSettings({
      tiktok_connected: true,
      advertiser_id: tokens.advertiser_ids?.[0],
      account_name: '@yasmineli__',
    });

    // In production: save access_token to secure storage (env or encrypted DB)
    console.log('[TikTok OAuth] Connected! Advertiser IDs:', tokens.advertiser_ids);

    return NextResponse.redirect(
      `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/?connected=true`
    );
  } catch (err) {
    console.error('[TikTok OAuth] Error:', err);
    return NextResponse.redirect(
      `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/?error=token_exchange_failed`
    );
  }
}
