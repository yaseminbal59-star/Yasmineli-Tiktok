// src/app/api/tiktok/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { tiktokClient } from '@/lib/tiktok-api';
import { getSettings, updateSettings, getDashboardStats } from '@/lib/db';

// GET /api/tiktok - get connection status + stats
export async function GET() {
  const settings = getSettings();
  const stats = getDashboardStats();

  let tiktokStats = null;
  if (settings.tiktok_connected) {
    try {
      tiktokStats = await tiktokClient.getAccountOverview();
    } catch {
      // Demo mode
    }
  }

  return NextResponse.json({
    success: true,
    data: {
      connected: settings.tiktok_connected,
      account_name: settings.account_name || '@yasmineli__',
      advertiser_id: settings.advertiser_id,
      auth_url: tiktokClient.getAuthUrl(),
      stats,
      tiktok_live_stats: tiktokStats,
    },
  });
}

// POST /api/tiktok - connect / disconnect
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { action } = body;

  if (action === 'disconnect') {
    updateSettings({ tiktok_connected: false, advertiser_id: undefined });
    return NextResponse.json({ success: true, message: 'Bağlantı kesildi' });
  }

  if (action === 'demo_connect') {
    // Demo mode: simulate connection without real credentials
    updateSettings({
      tiktok_connected: true,
      account_name: '@yasmineli__',
      advertiser_id: 'DEMO_ADV_ID',
    });
    return NextResponse.json({ success: true, message: 'Demo mod bağlantısı kuruldu', demo: true });
  }

  return NextResponse.json({ success: false, error: 'Bilinmeyen action' }, { status: 400 });
}
