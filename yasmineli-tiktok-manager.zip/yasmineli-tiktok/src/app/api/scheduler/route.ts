// src/app/api/scheduler/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getScheduledPosts, createScheduledPost } from '@/lib/db';

export async function GET() {
  const posts = getScheduledPosts();
  return NextResponse.json({ success: true, data: posts });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { title, caption, markets, scheduled_at, video_path } = body;

    if (!title || !caption || !markets?.length || !scheduled_at) {
      return NextResponse.json(
        { success: false, error: 'Eksik alanlar: title, caption, markets, scheduled_at zorunlu' },
        { status: 400 }
      );
    }

    const post = createScheduledPost({ title, caption, markets, scheduled_at, video_path });
    return NextResponse.json({ success: true, data: post }, { status: 201 });
  } catch (err) {
    return NextResponse.json({ success: false, error: (err as Error).message }, { status: 500 });
  }
}
