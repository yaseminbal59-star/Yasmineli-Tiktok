// src/app/api/dashboard/route.ts
import { NextResponse } from 'next/server';
import { getDashboardStats, getCampaigns, getScheduledPosts, getSettings } from '@/lib/db';
import { MARKETS } from '@/lib/tiktok-api';

export async function GET() {
  const stats = getDashboardStats();
  const campaigns = getCampaigns();
  const posts = getScheduledPosts();
  const settings = getSettings();

  // Market breakdown
  const marketStats: Record<string, { spend: number; impressions: number; clicks: number; ctr: number }> = {};

  for (const campaign of campaigns) {
    for (const market of campaign.markets) {
      if (!marketStats[market]) {
        marketStats[market] = { spend: 0, impressions: 0, clicks: 0, ctr: 0 };
      }
      const perMarket = campaign.markets.length;
      marketStats[market].spend += campaign.spend / perMarket;
      marketStats[market].impressions += campaign.impressions / perMarket;
      marketStats[market].clicks += campaign.clicks / perMarket;
    }
  }

  // Calculate CTR per market
  for (const m of Object.keys(marketStats)) {
    const ms = marketStats[m];
    ms.ctr = ms.impressions > 0 ? (ms.clicks / ms.impressions) * 100 : 0;
  }

  // Enrich with market info
  const marketBreakdown = Object.entries(marketStats).map(([code, data]) => ({
    code,
    ...MARKETS[code],
    ...data,
  }));

  // Upcoming posts (next 7 days)
  const now = new Date();
  const in7days = new Date(now.getTime() + 7 * 24 * 3600 * 1000);
  const upcomingPosts = posts
    .filter(p => p.status === 'scheduled' && new Date(p.scheduled_at) >= now && new Date(p.scheduled_at) <= in7days)
    .sort((a, b) => new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime())
    .slice(0, 5);

  return NextResponse.json({
    success: true,
    data: {
      ...stats,
      roas: stats.total_spend > 0 ? ((stats.total_conversions * 150) / stats.total_spend).toFixed(1) : '0',
      market_breakdown: marketBreakdown,
      upcoming_posts: upcomingPosts,
      tiktok_connected: settings.tiktok_connected,
      account_name: settings.account_name || '@yasmineli__',
    },
  });
}
