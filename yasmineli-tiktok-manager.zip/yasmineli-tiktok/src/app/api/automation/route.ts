// src/app/api/automation/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getAutomationRules, createAutomationRule, updateAutomationRule } from '@/lib/db';
import { runAllAutomations, generateCaptions } from '@/lib/automation';

export async function GET() {
  const rules = getAutomationRules();
  return NextResponse.json({ success: true, data: rules });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action } = body;

    // Special actions
    if (action === 'run_all') {
      const result = await runAllAutomations();
      return NextResponse.json({ success: true, data: result });
    }

    if (action === 'generate_captions') {
      const { product, markets, tone } = body;
      const captions = await generateCaptions({ product, markets, tone });
      return NextResponse.json({ success: true, data: captions });
    }

    if (action === 'toggle') {
      const { id, enabled } = body;
      const updated = updateAutomationRule(id, { enabled });
      return NextResponse.json({ success: true, data: updated });
    }

    // Create new rule
    const { name, type, config, enabled } = body;
    if (!name || !type) {
      return NextResponse.json({ success: false, error: 'name ve type zorunlu' }, { status: 400 });
    }
    const rule = createAutomationRule({ name, type, config: config || {}, enabled: enabled ?? true });
    return NextResponse.json({ success: true, data: rule }, { status: 201 });
  } catch (err) {
    return NextResponse.json({ success: false, error: (err as Error).message }, { status: 500 });
  }
}
