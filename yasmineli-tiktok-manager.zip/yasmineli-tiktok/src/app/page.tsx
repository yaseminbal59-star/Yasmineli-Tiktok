'use client';
import { useState, useEffect, useCallback } from 'react';

// ─── Types ────────────────────────────────────────────────────────────────────

interface Campaign {
  id: string; name: string; objective: string; ad_type: string;
  markets: string[]; budget_daily: number; spend: number;
  impressions: number; clicks: number; conversions: number;
  ctr: number; status: string; start_date: string;
  tiktok_campaign_id?: string;
}

interface ScheduledPost {
  id: string; title: string; caption: string; markets: string[];
  scheduled_at: string; status: string; tiktok_post_id?: string;
}

interface AutomationRule {
  id: string; name: string; type: string;
  config: Record<string, unknown>; enabled: boolean;
  last_run?: string; next_run?: string;
}

interface DashboardData {
  total_spend: number; total_impressions: number; avg_ctr: number;
  total_conversions: number; active_campaigns: number;
  scheduled_posts: number; active_automations: number; roas: string;
  market_breakdown: MarketBreakdown[]; upcoming_posts: ScheduledPost[];
  tiktok_connected: boolean; account_name: string;
}

interface MarketBreakdown {
  code: string; name: string; flag: string;
  spend: number; impressions: number; ctr: number;
}

const MARKETS: Record<string, { name: string; flag: string }> = {
  GB: { name: 'Birleşik Krallık', flag: '🇬🇧' },
  US: { name: 'Amerika', flag: '🇺🇸' },
  TR: { name: 'Türkiye', flag: '🇹🇷' },
  DE: { name: 'Almanya', flag: '🇩🇪' },
  FR: { name: 'Fransa', flag: '🇫🇷' },
  AU: { name: 'Avustralya', flag: '🇦🇺' },
};

const AUTO_TYPES: Record<string, { icon: string; label: string }> = {
  recurring_post: { icon: '📅', label: 'Tekrarlayan Gönderi' },
  budget_optimizer: { icon: '📊', label: 'Bütçe Optimizasyonu' },
  performance_alert: { icon: '🔔', label: 'Performans Alarmı' },
  ab_test: { icon: '🎯', label: 'A/B Test' },
  caption_generator: { icon: '✍️', label: 'Caption Üretici' },
};

// ─── Toast ────────────────────────────────────────────────────────────────────

function Toast({ msg, type, onClose }: { msg: string; type: 'success' | 'error' | 'info'; onClose: () => void }) {
  useEffect(() => { const t = setTimeout(onClose, 3500); return () => clearTimeout(t); }, [onClose]);
  const colors = { success: '#00e5a0', error: '#fe2c55', info: '#25f4ee' };
  return (
    <div style={{ position: 'fixed', bottom: 24, right: 24, zIndex: 9999, background: '#16161f', border: `1px solid ${colors[type]}`, borderRadius: 12, padding: '12px 18px', fontSize: 13, display: 'flex', alignItems: 'center', gap: 10, boxShadow: `0 4px 24px rgba(0,0,0,.5)`, animation: 'fadeInUp .3s ease' }}>
      <span style={{ color: colors[type], fontSize: 16 }}>{type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ'}</span>
      {msg}
    </div>
  );
}

// ─── Stat Card ────────────────────────────────────────────────────────────────

function StatCard({ icon, label, value, change, color }: { icon: string; label: string; value: string; change?: string; color?: string }) {
  return (
    <div style={{ background: '#16161f', border: '1px solid #1e1e2e', borderRadius: 16, padding: 20, transition: 'all .25s', cursor: 'default' }}
      onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.borderColor = 'rgba(254,44,85,.3)'; (e.currentTarget as HTMLDivElement).style.transform = 'translateY(-2px)'; }}
      onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.borderColor = '#1e1e2e'; (e.currentTarget as HTMLDivElement).style.transform = 'none'; }}>
      <div style={{ fontSize: 11, color: '#6b6b8a', fontWeight: 600, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>{icon} {label}</div>
      <div style={{ fontSize: 28, fontWeight: 700, fontFamily: 'monospace', color: color || '#f0f0f8', letterSpacing: -1 }}>{value}</div>
      {change && <div style={{ fontSize: 12, color: '#00e5a0', marginTop: 4 }}>↑ {change}</div>}
    </div>
  );
}

// ─── Status Badge ─────────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { color: string; bg: string; label: string }> = {
    active: { color: '#00e5a0', bg: 'rgba(0,229,160,.12)', label: 'Aktif' },
    paused: { color: '#ffb547', bg: 'rgba(255,181,71,.12)', label: 'Duraklat' },
    scheduled: { color: '#25f4ee', bg: 'rgba(37,244,238,.1)', label: 'Planlandı' },
    ended: { color: '#6b6b8a', bg: 'rgba(107,107,138,.1)', label: 'Bitti' },
    draft: { color: '#ffb547', bg: 'rgba(255,181,71,.12)', label: 'Taslak' },
    published: { color: '#00e5a0', bg: 'rgba(0,229,160,.12)', label: 'Yayınlandı' },
    failed: { color: '#fe2c55', bg: 'rgba(254,44,85,.12)', label: 'Başarısız' },
  };
  const s = map[status] || map.scheduled;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 11, fontWeight: 600, padding: '3px 8px', borderRadius: 6, color: s.color, background: s.bg }}>
      <span style={{ width: 5, height: 5, borderRadius: '50%', background: s.color, display: 'inline-block' }} />
      {s.label}
    </span>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function Home() {
  const [page, setPage] = useState('dashboard');
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [posts, setPosts] = useState<ScheduledPost[]>([]);
  const [automations, setAutomations] = useState<AutomationRule[]>([]);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Modals
  const [showCampModal, setShowCampModal] = useState(false);
  const [showPostModal, setShowPostModal] = useState(false);
  const [showAutoModal, setShowAutoModal] = useState(false);
  const [showCaptionModal, setShowCaptionModal] = useState(false);
  const [generatedCaptions, setGeneratedCaptions] = useState<Record<string, string>>({});
  const [captionLoading, setCaptionLoading] = useState(false);

  // Forms
  const [campForm, setCampForm] = useState({ name: '', objective: 'REACH', ad_type: 'In-Feed Ads', markets: ['GB', 'US'], budget_daily: 200, start_date: '' });
  const [postForm, setPostForm] = useState({ title: '', caption: '', markets: ['GB', 'US'], scheduled_at: '' });
  const [autoForm, setAutoForm] = useState({ name: '', type: 'recurring_post', enabled: true });
  const [captionForm, setCaptionForm] = useState({ product: 'Yasmineli Luxury Beşik', markets: ['GB', 'US', 'TR'], tone: 'luxury' });

  const toast$ = (msg: string, type: 'success' | 'error' | 'info' = 'success') => setToast({ msg, type });

  const api = useCallback(async (url: string, opts?: RequestInit) => {
    const res = await fetch(url, opts);
    return res.json();
  }, []);

  // Load data
  useEffect(() => {
    loadDashboard();
  }, []);

  useEffect(() => {
    if (page === 'campaigns') loadCampaigns();
    if (page === 'scheduler') loadPosts();
    if (page === 'automation') loadAutomations();
  }, [page]);

  async function loadDashboard() {
    setLoading(true);
    const d = await api('/api/dashboard');
    if (d.success) setDashboard(d.data);
    setLoading(false);
  }

  async function loadCampaigns() {
    const d = await api('/api/campaigns');
    if (d.success) setCampaigns(d.data);
  }

  async function loadPosts() {
    const d = await api('/api/scheduler');
    if (d.success) setPosts(d.data);
  }

  async function loadAutomations() {
    const d = await api('/api/automation');
    if (d.success) setAutomations(d.data);
  }

  async function createCampaign() {
    if (!campForm.name || !campForm.budget_daily) return toast$('Kampanya adı ve bütçe zorunlu', 'error');
    const d = await api('/api/campaigns', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(campForm) });
    if (d.success) {
      toast$('Kampanya oluşturuldu!');
      setShowCampModal(false);
      loadCampaigns();
      loadDashboard();
    } else toast$(d.error, 'error');
  }

  async function toggleCampaign(id: string, status: string) {
    const newStatus = status === 'active' ? 'paused' : 'active';
    const d = await api(`/api/campaigns/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: newStatus }) });
    if (d.success) { toast$(newStatus === 'active' ? 'Kampanya aktif edildi' : 'Kampanya duraklatıldı'); loadCampaigns(); }
    else toast$(d.error, 'error');
  }

  async function deleteCampaign(id: string) {
    if (!confirm('Kampanya silinsin mi?')) return;
    const d = await api(`/api/campaigns/${id}`, { method: 'DELETE' });
    if (d.success) { toast$('Kampanya silindi'); loadCampaigns(); loadDashboard(); }
    else toast$(d.error, 'error');
  }

  async function createPost() {
    if (!postForm.title || !postForm.caption || !postForm.scheduled_at) return toast$('Tüm alanlar zorunlu', 'error');
    const d = await api('/api/scheduler', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(postForm) });
    if (d.success) { toast$('Gönderi zamanlandı!'); setShowPostModal(false); loadPosts(); }
    else toast$(d.error, 'error');
  }

  async function toggleAutomation(id: string, enabled: boolean) {
    const d = await api('/api/automation', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'toggle', id, enabled: !enabled }) });
    if (d.success) { toast$(!enabled ? 'Otomasyon aktif' : 'Otomasyon durduruldu'); loadAutomations(); }
  }

  async function runAutomations() {
    setLoading(true);
    const d = await api('/api/automation', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'run_all' }) });
    setLoading(false);
    if (d.success) toast$(`${d.data.posts.published} gönderi yayınlandı, ${d.data.budget.actions.length} bütçe işlemi yapıldı`);
    else toast$(d.error, 'error');
  }

  async function genCaptions() {
    setCaptionLoading(true);
    const d = await api('/api/automation', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'generate_captions', ...captionForm }) });
    setCaptionLoading(false);
    if (d.success) { setGeneratedCaptions(d.data); }
    else toast$(d.error, 'error');
  }

  async function connectTikTok() {
    const d = await api('/api/tiktok', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'demo_connect' }) });
    if (d.success) { toast$('TikTok bağlandı! (Demo mod)'); loadDashboard(); }
  }

  function toggleMarket(list: string[], market: string): string[] {
    return list.includes(market) ? list.filter(m => m !== market) : [...list, market];
  }

  // ─── Shared Styles ────────────────────────────────────────────────────────

  const s = {
    panel: { background: '#16161f', border: '1px solid #1e1e2e', borderRadius: 16, padding: 20 } as React.CSSProperties,
    btn: { border: 'none', borderRadius: 8, padding: '8px 16px', fontSize: 13, fontWeight: 600, cursor: 'pointer', transition: 'all .2s' } as React.CSSProperties,
    btnPrimary: { background: 'linear-gradient(135deg,#fe2c55,#d41f45)', color: '#fff', boxShadow: '0 3px 12px rgba(254,44,85,.35)' } as React.CSSProperties,
    btnSecondary: { background: '#16161f', color: '#f0f0f8', border: '1px solid #1e1e2e' } as React.CSSProperties,
    input: { width: '100%', background: '#111118', border: '1px solid #1e1e2e', borderRadius: 8, color: '#f0f0f8', fontFamily: 'inherit', fontSize: 13, padding: '9px 12px', outline: 'none', transition: 'border-color .2s', boxSizing: 'border-box' as const },
    label: { fontSize: 11, fontWeight: 600, color: '#6b6b8a', display: 'block', marginBottom: 5, textTransform: 'uppercase' as const, letterSpacing: .4 },
    mktChip: (active: boolean): React.CSSProperties => ({ padding: '5px 10px', borderRadius: 8, fontSize: 12, cursor: 'pointer', border: `1px solid ${active ? '#fe2c55' : '#1e1e2e'}`, background: active ? 'rgba(254,44,85,.12)' : '#111118', color: active ? '#fe2c55' : '#6b6b8a', display: 'flex', alignItems: 'center', gap: 4 }),
  };

  const navItem = (id: string, icon: string, label: string, badge?: string) => (
    <div key={id} onClick={() => setPage(id)} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', borderRadius: 10, fontSize: 13.5, fontWeight: 500, cursor: 'pointer', color: page === id ? '#fe2c55' : '#6b6b8a', background: page === id ? 'rgba(254,44,85,.12)' : 'transparent', marginBottom: 2, transition: 'all .2s' }}>
      <span style={{ fontSize: 16, width: 20, textAlign: 'center' }}>{icon}</span>
      {label}
      {badge && <span style={{ marginLeft: 'auto', background: badge === 'ai' ? '#25f4ee' : '#fe2c55', color: badge === 'ai' ? '#000' : '#fff', fontSize: 10, fontWeight: 700, padding: '1px 6px', borderRadius: 20 }}>{badge}</span>}
    </div>
  );

  // ─── Modal Shell ──────────────────────────────────────────────────────────

  const Modal = ({ open, onClose, title, sub, children, onSubmit, submitLabel }: { open: boolean; onClose: () => void; title: string; sub?: string; children: React.ReactNode; onSubmit?: () => void; submitLabel?: string }) =>
    open ? (
      <div onClick={e => e.target === e.currentTarget && onClose()} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.7)', backdropFilter: 'blur(8px)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ background: '#16161f', border: '1px solid #1e1e2e', borderRadius: 20, padding: 28, width: 480, maxWidth: '90vw', animation: 'fadeInUp .25s ease' }}>
          <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 4 }}>{title}</div>
          {sub && <div style={{ fontSize: 13, color: '#6b6b8a', marginBottom: 20 }}>{sub}</div>}
          {children}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 20 }}>
            <button style={{ ...s.btn, ...s.btnSecondary }} onClick={onClose}>İptal</button>
            {onSubmit && <button style={{ ...s.btn, ...s.btnPrimary }} onClick={onSubmit}>{submitLabel || 'Kaydet'}</button>}
          </div>
        </div>
      </div>
    ) : null;

  // ─── Pages ────────────────────────────────────────────────────────────────

  const titles: Record<string, [string, string]> = {
    dashboard: ['Dashboard', 'Tüm kampanya ve otomasyon özeti'],
    campaigns: ['Kampanyalar', 'TikTok reklam kampanyalarını yönet'],
    scheduler: ['Gönderi Zamanlama', 'Otomatik içerik takvimi'],
    automation: ['Otomasyon', 'Tekrarlayan görevleri otomatikleştir'],
    analytics: ['Analitik', 'Performans detayları'],
    audience: ['Hedef Kitleler', 'Global pazar segmentleri'],
    integrations: ['Entegrasyonlar', 'Uygulama bağlantıları'],
    settings: ['Ayarlar', 'Hesap ve bildirim tercihleri'],
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#0a0a0f', color: '#f0f0f8', fontFamily: '"DM Sans",system-ui,sans-serif', position: 'relative' }}>

      {/* BG Glow */}
      <div style={{ position: 'fixed', top: '-40%', left: '-10%', width: '50%', height: '90%', background: 'radial-gradient(ellipse,rgba(254,44,85,.06) 0%,transparent 70%)', pointerEvents: 'none', zIndex: 0 }} />
      <div style={{ position: 'fixed', bottom: '-20%', right: '-10%', width: '50%', height: '80%', background: 'radial-gradient(ellipse,rgba(37,244,238,.04) 0%,transparent 70%)', pointerEvents: 'none', zIndex: 0 }} />

      {/* SIDEBAR */}
      <nav style={{ width: 240, background: '#111118', borderRight: '1px solid #1e1e2e', display: 'flex', flexDirection: 'column', position: 'fixed', top: 0, left: 0, height: '100vh', zIndex: 100 }}>
        <div style={{ padding: '20px', borderBottom: '1px solid #1e1e2e', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 36, height: 36, background: 'linear-gradient(135deg,#fe2c55,#25f4ee)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, boxShadow: '0 0 18px rgba(254,44,85,.4)' }}>♪</div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700 }}>Yasmineli</div>
            <div style={{ fontSize: 10, color: '#6b6b8a', fontFamily: 'monospace' }}>TikTok Manager</div>
          </div>
        </div>

        <div style={{ padding: '16px 12px', flex: 1, overflowY: 'auto' }}>
          <div style={{ fontSize: 10, color: '#6b6b8a', fontFamily: 'monospace', textTransform: 'uppercase', letterSpacing: 1, padding: '6px 8px 4px' }}>Yönetim</div>
          {navItem('dashboard', '📊', 'Dashboard')}
          {navItem('campaigns', '📣', 'Kampanyalar', String(campaigns.filter(c => c.status === 'active').length || ''))}
          {navItem('scheduler', '🗓', 'Gönderi Zamanlama')}
          {navItem('automation', '⚡', 'Otomasyon', 'ai')}
          <div style={{ fontSize: 10, color: '#6b6b8a', fontFamily: 'monospace', textTransform: 'uppercase', letterSpacing: 1, padding: '12px 8px 4px' }}>Analitik</div>
          {navItem('analytics', '📈', 'Performans')}
          {navItem('audience', '🌍', 'Hedef Kitleler')}
          <div style={{ fontSize: 10, color: '#6b6b8a', fontFamily: 'monospace', textTransform: 'uppercase', letterSpacing: 1, padding: '12px 8px 4px' }}>Hesap</div>
          {navItem('integrations', '🔗', 'Entegrasyonlar')}
          {navItem('settings', '⚙️', 'Ayarlar')}
        </div>

        <div style={{ padding: 16, borderTop: '1px solid #1e1e2e' }}>
          <button onClick={dashboard?.tiktok_connected ? undefined : connectTikTok}
            style={{ width: '100%', background: dashboard?.tiktok_connected ? 'linear-gradient(135deg,rgba(0,229,160,.15),rgba(0,229,160,.05))' : 'linear-gradient(135deg,#fe2c55,#ff6b35)', border: dashboard?.tiktok_connected ? '1px solid rgba(0,229,160,.3)' : 'none', borderRadius: 10, color: dashboard?.tiktok_connected ? '#00e5a0' : '#fff', fontSize: 13, fontWeight: 600, padding: '10px 16px', cursor: dashboard?.tiktok_connected ? 'default' : 'pointer', display: 'flex', alignItems: 'center', gap: 8, justifyContent: 'center', boxShadow: dashboard?.tiktok_connected ? 'none' : '0 4px 20px rgba(254,44,85,.35)' }}>
            ♪ {dashboard?.tiktok_connected ? `${dashboard.account_name} ✓` : 'TikTok Bağla'}
          </button>
        </div>
      </nav>

      {/* MAIN */}
      <main style={{ marginLeft: 240, flex: 1, padding: 28, position: 'relative', zIndex: 1 }}>

        {/* Topbar */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 28 }}>
          <div>
            <h1 style={{ fontSize: 22, fontWeight: 700, margin: 0 }}>{titles[page]?.[0]}</h1>
            <p style={{ fontSize: 13, color: '#6b6b8a', margin: '2px 0 0' }}>{titles[page]?.[1]}</p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: '#16161f', border: '1px solid #1e1e2e', borderRadius: 40, padding: '6px 14px 6px 8px', fontSize: 13 }}>
              <div style={{ width: 28, height: 28, background: 'linear-gradient(135deg,#fe2c55,#25f4ee)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700 }}>Y</div>
              {dashboard?.account_name || '@yasmineli__'}
              <div style={{ width: 7, height: 7, borderRadius: '50%', background: dashboard?.tiktok_connected ? '#00e5a0' : '#ffb547', boxShadow: `0 0 6px ${dashboard?.tiktok_connected ? '#00e5a0' : '#ffb547'}` }} />
            </div>
            {page === 'campaigns' && <button style={{ ...s.btn, ...s.btnPrimary }} onClick={() => setShowCampModal(true)}>+ Kampanya</button>}
            {page === 'scheduler' && <button style={{ ...s.btn, ...s.btnPrimary }} onClick={() => setShowPostModal(true)}>+ Gönderi Zamanla</button>}
            {page === 'automation' && <button style={{ ...s.btn, ...s.btnPrimary }} onClick={runAutomations}>⚡ Hepsini Çalıştır</button>}
          </div>
        </div>

        {loading && <div style={{ textAlign: 'center', padding: 40, color: '#6b6b8a', fontSize: 14 }}>Yükleniyor...</div>}

        {/* ═══ DASHBOARD ════════════════════════════════════════════════════════ */}
        {page === 'dashboard' && dashboard && (
          <div>
            {!dashboard.tiktok_connected && (
              <div style={{ background: 'rgba(254,44,85,.08)', border: '1px solid rgba(254,44,85,.2)', borderRadius: 10, padding: '12px 16px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10, fontSize: 13 }}>
                <span style={{ fontSize: 18 }}>⚠️</span>
                <span>TikTok hesabı henüz bağlı değil. <span style={{ color: '#fe2c55', cursor: 'pointer', fontWeight: 600 }} onClick={connectTikTok}>Şimdi bağla →</span></span>
              </div>
            )}
            <div style={{ background: 'rgba(37,244,238,.08)', border: '1px solid rgba(37,244,238,.2)', borderRadius: 10, padding: '12px 16px', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 10, fontSize: 13 }}>
              <span style={{ fontSize: 18 }}>⚡</span>
              <span>{dashboard.active_automations} otomasyon aktif · {dashboard.scheduled_posts} gönderi planlandı · Gerçek zamanlı optimizasyon çalışıyor</span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16, marginBottom: 24 }}>
              <StatCard icon="💰" label="Toplam Harcama" value={`₺${(dashboard.total_spend / 1000).toFixed(1)}K`} change="%23 bu ay" color="#fe2c55" />
              <StatCard icon="👁" label="Görüntülenme" value={`${(dashboard.total_impressions / 1000000).toFixed(1)}M`} change="%41" color="#25f4ee" />
              <StatCard icon="🖱" label="Ort. CTR" value={`${dashboard.avg_ctr.toFixed(1)}%`} change="0.8pp" />
              <StatCard icon="🛒" label="Dönüşüm" value={String(dashboard.total_conversions)} change="%18" color="#00e5a0" />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16, marginBottom: 20 }}>
              {/* Market Breakdown */}
              <div style={s.panel}>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 14 }}>🌍 Pazar Performansı</div>
                {dashboard.market_breakdown.map(m => (
                  <div key={m.code} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '1px solid rgba(30,30,46,.6)' }}>
                    <span style={{ fontSize: 22 }}>{m.flag}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{m.name}</div>
                      <div style={{ fontSize: 11, color: '#6b6b8a' }}>{(m.impressions / 1000).toFixed(0)}K görüntülenme · {m.ctr.toFixed(1)}% CTR</div>
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ height: 5, background: '#1e1e2e', borderRadius: 3, overflow: 'hidden' }}>
                        <div style={{ height: '100%', width: `${Math.min(m.ctr * 12, 100)}%`, background: 'linear-gradient(90deg,#fe2c55,#ff6b35)', borderRadius: 3 }} />
                      </div>
                    </div>
                    <div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 700, minWidth: 55, textAlign: 'right' }}>₺{(m.spend / 1000).toFixed(1)}K</div>
                  </div>
                ))}
              </div>

              {/* Upcoming Posts */}
              <div style={s.panel}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>⏰ Yaklaşan Gönderiler</div>
                  <button style={{ ...s.btn, ...s.btnSecondary, fontSize: 11 }} onClick={() => setPage('scheduler')}>Takvim →</button>
                </div>
                {dashboard.upcoming_posts.length === 0 && (
                  <div style={{ color: '#6b6b8a', fontSize: 13, textAlign: 'center', padding: 20 }}>Planlanmış gönderi yok.<br /><span style={{ color: '#fe2c55', cursor: 'pointer' }} onClick={() => setShowPostModal(true)}>+ Yeni zamanla</span></div>
                )}
                {dashboard.upcoming_posts.map(p => (
                  <div key={p.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: '#111118', borderRadius: 10, border: '1px solid #1e1e2e', marginBottom: 8 }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{p.title}</div>
                      <div style={{ fontSize: 11, color: '#6b6b8a' }}>{new Date(p.scheduled_at).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })} · {p.markets.map(m => MARKETS[m]?.flag).join('')}</div>
                    </div>
                    <StatusBadge status={p.status} />
                  </div>
                ))}
                <button style={{ ...s.btn, ...s.btnPrimary, width: '100%', marginTop: 4 }} onClick={() => setShowPostModal(true)}>+ Gönderi Zamanla</button>
              </div>
            </div>
          </div>
        )}

        {/* ═══ CAMPAIGNS ════════════════════════════════════════════════════════ */}
        {page === 'campaigns' && (
          <div>
            <div style={s.panel}>
              <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
                {['Tümü', 'Aktif', 'Duraklatıldı', 'Planlandı'].map(f => (
                  <button key={f} style={{ ...s.btn, ...s.btnSecondary, fontSize: 12 }}>{f} ({campaigns.filter(c => f === 'Tümü' || c.status === (f === 'Aktif' ? 'active' : f === 'Duraklatıldı' ? 'paused' : 'scheduled')).length})</button>
                ))}
              </div>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr>
                    {['Kampanya', 'Pazarlar', 'Bütçe/Gün', 'Harcama', 'Görüntülenme', 'CTR', 'Dönüşüm', 'Durum', 'İşlem'].map(h => (
                      <th key={h} style={{ fontSize: 11, fontWeight: 600, color: '#6b6b8a', textTransform: 'uppercase', letterSpacing: .5, padding: '8px 12px', textAlign: 'left', borderBottom: '1px solid #1e1e2e' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {campaigns.length === 0 && (
                    <tr><td colSpan={9} style={{ textAlign: 'center', padding: 40, color: '#6b6b8a' }}>Henüz kampanya yok. <span style={{ color: '#fe2c55', cursor: 'pointer' }} onClick={() => setShowCampModal(true)}>+ Yeni oluştur</span></td></tr>
                  )}
                  {campaigns.map(c => (
                    <tr key={c.id} style={{ transition: 'background .15s' }}
                      onMouseEnter={e => (e.currentTarget.style.background = 'rgba(254,44,85,.03)')}
                      onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                      <td style={{ padding: '12px', borderBottom: '1px solid rgba(30,30,46,.5)' }}>
                        <div style={{ fontWeight: 600, fontSize: 13 }}>{c.name}</div>
                        <div style={{ fontSize: 11, color: '#6b6b8a' }}>{c.ad_type} · {c.objective}</div>
                      </td>
                      <td style={{ padding: '12px', borderBottom: '1px solid rgba(30,30,46,.5)', fontSize: 18 }}>{c.markets.map(m => MARKETS[m]?.flag || m).join('')}</td>
                      <td style={{ padding: '12px', borderBottom: '1px solid rgba(30,30,46,.5)', fontFamily: 'monospace', fontSize: 13 }}>₺{c.budget_daily}</td>
                      <td style={{ padding: '12px', borderBottom: '1px solid rgba(30,30,46,.5)', fontFamily: 'monospace', fontSize: 13 }}>₺{c.spend.toLocaleString('tr-TR')}</td>
                      <td style={{ padding: '12px', borderBottom: '1px solid rgba(30,30,46,.5)', fontFamily: 'monospace', fontSize: 13 }}>{(c.impressions / 1000).toFixed(0)}K</td>
                      <td style={{ padding: '12px', borderBottom: '1px solid rgba(30,30,46,.5)', fontFamily: 'monospace', fontSize: 13, color: c.ctr >= 4 ? '#00e5a0' : c.ctr >= 2.5 ? '#ffb547' : '#fe2c55' }}>{c.ctr.toFixed(1)}%</td>
                      <td style={{ padding: '12px', borderBottom: '1px solid rgba(30,30,46,.5)', fontFamily: 'monospace', fontSize: 13 }}>{c.conversions}</td>
                      <td style={{ padding: '12px', borderBottom: '1px solid rgba(30,30,46,.5)' }}><StatusBadge status={c.status} /></td>
                      <td style={{ padding: '12px', borderBottom: '1px solid rgba(30,30,46,.5)' }}>
                        <div style={{ display: 'flex', gap: 5 }}>
                          <button title={c.status === 'active' ? 'Duraklat' : 'Aktif Et'} onClick={() => toggleCampaign(c.id, c.status)}
                            style={{ width: 28, height: 28, background: '#111118', border: '1px solid #1e1e2e', borderRadius: 7, cursor: 'pointer', fontSize: 12 }}>
                            {c.status === 'active' ? '⏸' : '▶️'}
                          </button>
                          <button title="Sil" onClick={() => deleteCampaign(c.id)}
                            style={{ width: 28, height: 28, background: '#111118', border: '1px solid #1e1e2e', borderRadius: 7, cursor: 'pointer', fontSize: 12 }}>🗑</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ═══ SCHEDULER ════════════════════════════════════════════════════════ */}
        {page === 'scheduler' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div>
              <div style={{ ...s.panel, marginBottom: 16 }}>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 14 }}>🌍 En İyi Gönderim Saatleri</div>
                {[{ code: 'GB', flag: '🇬🇧', name: 'UK', best: '19:00–21:00 GMT', color: '#fe2c55' }, { code: 'US', flag: '🇺🇸', name: 'US', best: '15:00–17:00 EST', color: '#25f4ee' }, { code: 'TR', flag: '🇹🇷', name: 'TR', best: '20:00–22:00 TRT', color: '#ffb547' }].map(m => (
                  <div key={m.code} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', background: '#111118', borderRadius: 10, border: '1px solid #1e1e2e', marginBottom: 8 }}>
                    <span style={{ fontSize: 22 }}>{m.flag}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{m.name} Kitlesi</div>
                      <div style={{ fontSize: 11, color: '#6b6b8a' }}>En iyi: {m.best}</div>
                    </div>
                    <div style={{ fontFamily: 'monospace', fontSize: 14, fontWeight: 700, color: m.color }}>{m.best.split('–')[0]}</div>
                  </div>
                ))}
              </div>

              <div style={{ ...s.panel, marginBottom: 16 }}>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 14 }}>✍️ AI Caption Üretici</div>
                <div style={{ marginBottom: 10 }}>
                  <label style={s.label}>Ürün</label>
                  <input style={s.input} value={captionForm.product} onChange={e => setCaptionForm(f => ({ ...f, product: e.target.value }))} />
                </div>
                <div style={{ marginBottom: 10 }}>
                  <label style={s.label}>Ton</label>
                  <select style={s.input} value={captionForm.tone} onChange={e => setCaptionForm(f => ({ ...f, tone: e.target.value }))}>
                    <option value="luxury">Luxury</option>
                    <option value="playful">Eğlenceli</option>
                    <option value="informative">Bilgilendirici</option>
                  </select>
                </div>
                <div style={{ marginBottom: 12 }}>
                  <label style={s.label}>Pazarlar</label>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    {Object.entries(MARKETS).map(([k, v]) => (
                      <div key={k} style={s.mktChip(captionForm.markets.includes(k))} onClick={() => setCaptionForm(f => ({ ...f, markets: toggleMarket(f.markets, k) }))}>
                        {v.flag} {k}
                      </div>
                    ))}
                  </div>
                </div>
                <button style={{ ...s.btn, ...s.btnPrimary, width: '100%' }} onClick={() => { setShowCaptionModal(true); genCaptions(); }}>
                  🤖 Caption Üret
                </button>
              </div>
            </div>

            <div style={s.panel}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
                <div style={{ fontSize: 14, fontWeight: 600 }}>📋 Planlanmış Gönderiler</div>
                <button style={{ ...s.btn, ...s.btnPrimary, fontSize: 12 }} onClick={() => setShowPostModal(true)}>+ Zamanla</button>
              </div>
              {posts.length === 0 && <div style={{ color: '#6b6b8a', textAlign: 'center', padding: 30, fontSize: 13 }}>Planlanmış gönderi yok.</div>}
              {posts.sort((a, b) => new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime()).map(p => (
                <div key={p.id} style={{ padding: '12px', background: '#111118', borderRadius: 10, border: '1px solid #1e1e2e', marginBottom: 8 }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 3 }}>{p.title}</div>
                      <div style={{ fontSize: 11, color: '#6b6b8a', marginBottom: 4 }}>{p.caption.slice(0, 60)}...</div>
                      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                        <span style={{ fontSize: 11, color: '#6b6b8a', fontFamily: 'monospace' }}>
                          {new Date(p.scheduled_at).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                        </span>
                        <span style={{ fontSize: 14 }}>{p.markets.map(m => MARKETS[m]?.flag || m).join('')}</span>
                      </div>
                    </div>
                    <StatusBadge status={p.status} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ═══ AUTOMATION ═══════════════════════════════════════════════════════ */}
        {page === 'automation' && (
          <div>
            <div style={{ marginBottom: 20 }}>
              {automations.map(rule => (
                <div key={rule.id} style={{ ...s.panel, display: 'flex', alignItems: 'center', gap: 16, marginBottom: 10 }}>
                  <div style={{ fontSize: 28 }}>{AUTO_TYPES[rule.type]?.icon || '⚙️'}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{rule.name}</div>
                    <div style={{ fontSize: 12, color: '#6b6b8a', marginTop: 3 }}>
                      {rule.type === 'recurring_post' && `Her hafta ${(rule.config as { day?: string }).day || 'pazartesi'} ${(rule.config as { time?: string }).time || '14:00'} · ${((rule.config as { markets?: string[] }).markets || []).map((m: string) => MARKETS[m]?.flag).join('')}`}
                      {rule.type === 'budget_optimizer' && `CTR %${(rule.config as { ctr_threshold?: number }).ctr_threshold || 3} altına düşünce bütçeyi optimize et`}
                      {rule.type === 'caption_generator' && `AI ile otomatik çok dilli caption üret · ${((rule.config as { markets?: string[] }).markets || []).map((m: string) => MARKETS[m]?.flag).join('')}`}
                      {rule.type === 'performance_alert' && 'Performans eşiği aşıldığında bildirim gönder'}
                    </div>
                    <div style={{ display: 'flex', gap: 8, marginTop: 6 }}>
                      {rule.last_run && <span style={{ fontSize: 11, color: '#6b6b8a' }}>Son çalışma: {new Date(rule.last_run).toLocaleString('tr-TR')}</span>}
                      {rule.next_run && <span style={{ fontSize: 11, color: '#25f4ee' }}>Sonraki: {new Date(rule.next_run).toLocaleString('tr-TR')}</span>}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <StatusBadge status={rule.enabled ? 'active' : 'paused'} />
                    <button onClick={() => toggleAutomation(rule.id, rule.enabled)}
                      style={{ ...s.btn, ...s.btnSecondary, fontSize: 12 }}>
                      {rule.enabled ? '⏸ Durdur' : '▶️ Başlat'}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 12 }}>➕ Şablon Ekle</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12 }}>
              {[
                { type: 'recurring_post', icon: '🔄', title: 'Tekrarlayan Gönderi', desc: 'Belirli aralıklarla otomatik içerik yayınla', color: '#fe2c55' },
                { type: 'performance_alert', icon: '🔔', title: 'Performans Alarmı', desc: 'CTR veya bütçe eşiği aşıldığında bildirim al', color: '#25f4ee' },
                { type: 'ab_test', icon: '🎯', title: 'A/B Test', desc: 'İki reklam versiyonunu karşılaştır, kazananı seç', color: '#00e5a0' },
              ].map(t => (
                <div key={t.type} style={{ ...s.panel, cursor: 'pointer', transition: 'all .2s' }}
                  onMouseEnter={e => (e.currentTarget.style.borderColor = `${t.color}66`)}
                  onMouseLeave={e => (e.currentTarget.style.borderColor = '#1e1e2e')}
                  onClick={() => { setAutoForm(f => ({ ...f, type: t.type, name: t.title })); setShowAutoModal(true); }}>
                  <div style={{ fontSize: 24, marginBottom: 8 }}>{t.icon}</div>
                  <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{t.title}</div>
                  <div style={{ fontSize: 12, color: '#6b6b8a' }}>{t.desc}</div>
                  <div style={{ marginTop: 12, fontSize: 12, color: t.color, fontWeight: 600 }}>+ Ekle →</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ═══ ANALYTICS ════════════════════════════════════════════════════════ */}
        {page === 'analytics' && dashboard && (
          <div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16, marginBottom: 24 }}>
              <StatCard icon="📊" label="Toplam Gösterim" value={`${(dashboard.total_impressions * 1.5 / 1000000).toFixed(1)}M`} change="%34" color="#fe2c55" />
              <StatCard icon="❤️" label="Beğeni (est.)" value={`${(dashboard.total_impressions * 0.05 / 1000).toFixed(0)}K`} change="%28" />
              <StatCard icon="💬" label="Yorum (est.)" value={`${(dashboard.total_impressions * 0.003 / 1000).toFixed(1)}K`} change="%12" color="#25f4ee" />
              <StatCard icon="📈" label="ROAS" value={`${dashboard.roas}x`} change="+0.4x" color="#00e5a0" />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div style={s.panel}>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 14 }}>📈 Haftalık Görüntülenme</div>
                <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 80 }}>
                  {[45, 60, 40, 75, 90, 65, 100].map((h, i) => (
                    <div key={i} style={{ flex: 1, height: `${h}%`, borderRadius: '3px 3px 0 0', background: 'linear-gradient(0deg,#fe2c55,#ff6b35)', opacity: .75, transition: 'opacity .2s', cursor: 'default' }}
                      onMouseEnter={e => ((e.currentTarget as HTMLDivElement).style.opacity = '1')}
                      onMouseLeave={e => ((e.currentTarget as HTMLDivElement).style.opacity = '.75')} />
                  ))}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: '#6b6b8a', fontFamily: 'monospace', marginTop: 6 }}>
                  {['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'].map(d => <span key={d}>{d}</span>)}
                </div>
              </div>
              <div style={s.panel}>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 14 }}>🎯 CTR — Pazar Bazlı</div>
                {dashboard.market_breakdown.map(m => (
                  <div key={m.code} style={{ marginBottom: 10 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
                      <span>{m.flag} {m.name}</span>
                      <span style={{ fontFamily: 'monospace', color: m.ctr >= 5 ? '#00e5a0' : m.ctr >= 3 ? '#ffb547' : '#fe2c55' }}>{m.ctr.toFixed(1)}%</span>
                    </div>
                    <div style={{ height: 7, background: '#1e1e2e', borderRadius: 3, overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${Math.min(m.ctr * 15, 100)}%`, background: 'linear-gradient(90deg,#fe2c55,#ff6b35)', borderRadius: 3, transition: 'width .5s' }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ═══ AUDIENCE ═════════════════════════════════════════════════════════ */}
        {page === 'audience' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div style={s.panel}>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 14 }}>🌍 Ülke Segmentleri</div>
              {[{ code: 'US', size: '2.4M', reach: 92 }, { code: 'GB', size: '1.8M', reach: 78 }, { code: 'TR', size: '1.1M', reach: 62 }, { code: 'DE', size: '900K', reach: 45 }, { code: 'FR', size: '720K', reach: 38 }, { code: 'AU', size: '420K', reach: 22 }].map(m => (
                <div key={m.code} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', background: '#111118', borderRadius: 10, border: '1px solid #1e1e2e', marginBottom: 8 }}>
                  <span style={{ fontSize: 22 }}>{MARKETS[m.code]?.flag}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{MARKETS[m.code]?.name}</div>
                    <div style={{ fontSize: 11, color: '#6b6b8a' }}>{m.size} potansiyel erişim</div>
                  </div>
                  <div style={{ width: 80 }}>
                    <div style={{ height: 4, background: '#1e1e2e', borderRadius: 2 }}>
                      <div style={{ height: '100%', width: `${m.reach}%`, background: 'linear-gradient(90deg,#fe2c55,#25f4ee)', borderRadius: 2 }} />
                    </div>
                  </div>
                  <div style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 700, color: '#fe2c55', minWidth: 32 }}>%{m.reach}</div>
                </div>
              ))}
            </div>
            <div style={s.panel}>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 14 }}>🎯 İlgi Alanı Segmentleri</div>
              {[{ icon: '👶', name: 'Yeni Ebeveynler', size: '4.2M', status: 'active' }, { icon: '🤰', name: 'Hamile Anneler', size: '1.8M', status: 'active' }, { icon: '🛏', name: 'Bebek Ürünleri', size: '3.1M', status: 'active' }, { icon: '💎', name: 'Lüks Bebek Markaları', size: '800K', status: 'scheduled' }].map(seg => (
                <div key={seg.name} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', background: '#111118', borderRadius: 10, border: '1px solid #1e1e2e', marginBottom: 8 }}>
                  <span style={{ fontSize: 22 }}>{seg.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{seg.name}</div>
                    <div style={{ fontSize: 11, color: '#6b6b8a' }}>{seg.size} kullanıcı</div>
                  </div>
                  <StatusBadge status={seg.status} />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ═══ INTEGRATIONS ═════════════════════════════════════════════════════ */}
        {page === 'integrations' && (
          <div>
            {[
              { icon: '♪', name: 'TikTok Business API', desc: 'Reklam yönetimi, kampanya oluşturma · @yasmineli__', connected: dashboard?.tiktok_connected || false },
              { icon: '📊', name: 'TikTok Ads Manager', desc: 'Tam reklam kampanyası yönetimi ve optimizasyon', connected: dashboard?.tiktok_connected || false },
              { icon: '💬', name: 'WhatsApp Business', desc: 'Reklam dönüşümlerini WhatsApp\'a yönlendir', connected: true },
              { icon: '📸', name: 'Instagram (Meta)', desc: 'Instagram ile çapraz gönderi ve Meta Ads entegrasyonu', connected: false },
              { icon: '🛒', name: 'TikTok Shop', desc: 'Ürün kataloğu ve doğrudan satış entegrasyonu', connected: false },
            ].map(int => (
              <div key={int.name} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 16, background: '#111118', borderRadius: 12, border: '1px solid #1e1e2e', marginBottom: 10, transition: 'all .2s' }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = 'rgba(254,44,85,.3)')}
                onMouseLeave={e => (e.currentTarget.style.borderColor = '#1e1e2e')}>
                <div style={{ fontSize: 28 }}>{int.icon}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{int.name}</div>
                  <div style={{ fontSize: 12, color: '#6b6b8a' }}>{int.desc}</div>
                </div>
                {int.connected
                  ? <span style={{ background: 'rgba(0,229,160,.12)', color: '#00e5a0', fontSize: 12, padding: '4px 10px', borderRadius: 6, fontWeight: 600 }}>✓ Bağlandı</span>
                  : <button onClick={int.name.includes('TikTok') ? connectTikTok : undefined}
                      style={{ background: 'rgba(254,44,85,.15)', color: '#fe2c55', fontSize: 12, padding: '4px 10px', borderRadius: 6, fontWeight: 600, border: 'none', cursor: 'pointer' }}>+ Bağla</button>}
              </div>
            ))}
          </div>
        )}

        {/* ═══ SETTINGS ═════════════════════════════════════════════════════════ */}
        {page === 'settings' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div style={s.panel}>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 16 }}>⚙️ Hesap Ayarları</div>
              {[['TikTok Hesabı', '@yasmineli__'], ['Marka Adı', 'Yasmineli']].map(([label, val]) => (
                <div key={label} style={{ marginBottom: 14 }}>
                  <label style={s.label}>{label}</label>
                  <input style={s.input} defaultValue={val} />
                </div>
              ))}
              <div style={{ marginBottom: 14 }}>
                <label style={s.label}>Para Birimi</label>
                <select style={s.input}>
                  <option>TRY - Türk Lirası</option>
                  <option>GBP - İngiliz Sterlini</option>
                  <option>USD - Amerikan Doları</option>
                </select>
              </div>
              <button style={{ ...s.btn, ...s.btnPrimary, marginTop: 4 }} onClick={() => toast$('Ayarlar kaydedildi')}>Kaydet</button>
            </div>
            <div style={s.panel}>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 16 }}>🔔 Bildirim Ayarları</div>
              {[['Bildirim E-postası', 'ornek@email.com']].map(([label, ph]) => (
                <div key={label} style={{ marginBottom: 14 }}>
                  <label style={s.label}>{label}</label>
                  <input style={s.input} placeholder={ph} />
                </div>
              ))}
              <div style={{ marginBottom: 14 }}>
                <label style={s.label}>Otomasyon Bildirimleri</label>
                <select style={s.input}>
                  <option>Anlık bildirim</option>
                  <option>Günlük özet</option>
                  <option>Haftalık rapor</option>
                </select>
              </div>
              <div style={{ marginBottom: 14 }}>
                <label style={s.label}>Bütçe Alarm Eşiği (%)</label>
                <input style={s.input} type="number" defaultValue={80} />
              </div>
              <button style={{ ...s.btn, ...s.btnPrimary, marginTop: 4 }} onClick={() => toast$('Ayarlar kaydedildi')}>Kaydet</button>
            </div>
          </div>
        )}
      </main>

      {/* ═══ MODALS ═══════════════════════════════════════════════════════════ */}

      {/* New Campaign */}
      <Modal open={showCampModal} onClose={() => setShowCampModal(false)} title="📣 Yeni Kampanya" sub="TikTok reklamını global pazarlar için yapılandır" onSubmit={createCampaign} submitLabel="🚀 Oluştur">
        <div style={{ marginBottom: 12 }}>
          <label style={s.label}>Kampanya Adı *</label>
          <input style={s.input} placeholder="UK Luxury Beşik 2025..." value={campForm.name} onChange={e => setCampForm(f => ({ ...f, name: e.target.value }))} />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
          <div>
            <label style={s.label}>Reklam Türü</label>
            <select style={s.input} value={campForm.ad_type} onChange={e => setCampForm(f => ({ ...f, ad_type: e.target.value }))}>
              {['In-Feed Ads', 'TopView Ads', 'Branded Hashtag', 'Spark Ads'].map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label style={s.label}>Amaç</label>
            <select style={s.input} value={campForm.objective} onChange={e => setCampForm(f => ({ ...f, objective: e.target.value }))}>
              {['REACH', 'TRAFFIC', 'VIDEO_VIEWS', 'CONVERSIONS'].map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
        </div>
        <div style={{ marginBottom: 12 }}>
          <label style={s.label}>Hedef Pazarlar *</label>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {Object.entries(MARKETS).map(([k, v]) => (
              <div key={k} style={s.mktChip(campForm.markets.includes(k))} onClick={() => setCampForm(f => ({ ...f, markets: toggleMarket(f.markets, k) }))}>
                {v.flag} {k}
              </div>
            ))}
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 4 }}>
          <div>
            <label style={s.label}>Günlük Bütçe (₺) *</label>
            <input style={s.input} type="number" value={campForm.budget_daily} onChange={e => setCampForm(f => ({ ...f, budget_daily: Number(e.target.value) }))} />
          </div>
          <div>
            <label style={s.label}>Başlangıç Tarihi</label>
            <input style={s.input} type="date" value={campForm.start_date} onChange={e => setCampForm(f => ({ ...f, start_date: e.target.value }))} />
          </div>
        </div>
      </Modal>

      {/* Schedule Post */}
      <Modal open={showPostModal} onClose={() => setShowPostModal(false)} title="🗓 Gönderi Zamanla" sub="İçeriğini otomatik yayınla" onSubmit={createPost} submitLabel="📅 Zamanla">
        <div style={{ marginBottom: 12 }}>
          <label style={s.label}>Başlık *</label>
          <input style={s.input} placeholder="Beşik Tanıtım..." value={postForm.title} onChange={e => setPostForm(f => ({ ...f, title: e.target.value }))} />
        </div>
        <div style={{ marginBottom: 12 }}>
          <label style={s.label}>Caption / Açıklama *</label>
          <textarea style={{ ...s.input, minHeight: 80, resize: 'vertical' }} placeholder="#yasmineli #luxurybaby..." value={postForm.caption} onChange={e => setPostForm(f => ({ ...f, caption: e.target.value }))} />
        </div>
        <div style={{ marginBottom: 12 }}>
          <label style={s.label}>Pazarlar</label>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {Object.entries(MARKETS).map(([k, v]) => (
              <div key={k} style={s.mktChip(postForm.markets.includes(k))} onClick={() => setPostForm(f => ({ ...f, markets: toggleMarket(f.markets, k) }))}>
                {v.flag} {k}
              </div>
            ))}
          </div>
        </div>
        <div>
          <label style={s.label}>Yayın Tarihi & Saati *</label>
          <input style={s.input} type="datetime-local" value={postForm.scheduled_at} onChange={e => setPostForm(f => ({ ...f, scheduled_at: e.target.value }))} />
        </div>
      </Modal>

      {/* New Automation */}
      <Modal open={showAutoModal} onClose={() => setShowAutoModal(false)} title="⚡ Yeni Otomasyon" sub="Tekrarlayan görevleri otomatikleştir" onSubmit={async () => { const d = await api('/api/automation', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(autoForm) }); if (d.success) { toast$('Otomasyon oluşturuldu!'); setShowAutoModal(false); loadAutomations(); } else toast$(d.error, 'error'); }} submitLabel="⚡ Oluştur">
        <div style={{ marginBottom: 12 }}>
          <label style={s.label}>Ad</label>
          <input style={s.input} value={autoForm.name} onChange={e => setAutoForm(f => ({ ...f, name: e.target.value }))} />
        </div>
        <div style={{ marginBottom: 12 }}>
          <label style={s.label}>Tür</label>
          <select style={s.input} value={autoForm.type} onChange={e => setAutoForm(f => ({ ...f, type: e.target.value }))}>
            {Object.entries(AUTO_TYPES).map(([k, v]) => <option key={k} value={k}>{v.icon} {v.label}</option>)}
          </select>
        </div>
      </Modal>

      {/* Caption Results */}
      <Modal open={showCaptionModal} onClose={() => setShowCaptionModal(false)} title="✍️ AI Caption Üretici" sub="Pazarlarınıza özel captionlar">
        {captionLoading ? (
          <div style={{ textAlign: 'center', padding: 30, color: '#6b6b8a' }}>🤖 AI üretiyor...</div>
        ) : (
          Object.entries(generatedCaptions).map(([market, caption]) => (
            <div key={market} style={{ marginBottom: 12, padding: 12, background: '#111118', borderRadius: 10, border: '1px solid #1e1e2e' }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#6b6b8a', marginBottom: 6 }}>{MARKETS[market]?.flag} {MARKETS[market]?.name}</div>
              <div style={{ fontSize: 13, lineHeight: 1.5 }}>{caption}</div>
              <button style={{ ...s.btn, background: 'transparent', border: 'none', color: '#fe2c55', fontSize: 11, padding: '4px 0', marginTop: 4 }}
                onClick={() => { navigator.clipboard.writeText(caption); toast$('Kopyalandı!'); }}>📋 Kopyala</button>
            </div>
          ))
        )}
        {!captionLoading && Object.keys(generatedCaptions).length === 0 && (
          <div style={{ color: '#6b6b8a', textAlign: 'center', padding: 20 }}>Üretmek için "Caption Üret" butonuna tıklayın</div>
        )}
      </Modal>

      {/* Toast */}
      {toast && <Toast msg={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}
