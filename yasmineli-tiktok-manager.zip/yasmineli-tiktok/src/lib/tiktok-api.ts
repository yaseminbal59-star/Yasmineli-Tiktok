// lib/tiktok-api.ts
// TikTok Business API & Content Posting API Client

const TIKTOK_ADS_BASE = 'https://business-api.tiktok.com/open_api/v1.3';
const TIKTOK_CONTENT_BASE = 'https://open.tiktokapis.com/v2';

// ─── Types ──────────────────────────────────────────────────────────────────

export interface TikTokCampaign {
  campaign_id: string;
  campaign_name: string;
  objective_type: string;
  budget: number;
  budget_mode: string;
  status: 'ENABLE' | 'DISABLE' | 'DELETE';
  create_time: number;
  modify_time: number;
}

export interface TikTokAdGroup {
  adgroup_id: string;
  adgroup_name: string;
  campaign_id: string;
  budget: number;
  schedule_start_time: string;
  schedule_end_time?: string;
  location_ids: string[];
  gender: string;
  age: string[];
  status: string;
}

export interface TikTokAd {
  ad_id: string;
  adgroup_id: string;
  ad_name: string;
  ad_text: string;
  image_ids?: string[];
  video_id?: string;
  status: string;
}

export interface CampaignMetrics {
  campaign_id: string;
  impressions: number;
  clicks: number;
  spend: number;
  ctr: number;
  cpm: number;
  conversions: number;
  conversion_rate: number;
  date_start: string;
  date_end: string;
}

export interface ScheduledPost {
  id: string;
  title: string;
  caption: string;
  video_path?: string;
  markets: string[];
  scheduled_at: string;
  status: 'draft' | 'scheduled' | 'published' | 'failed';
  tiktok_post_id?: string;
  created_at: string;
}

export interface AutomationRule {
  id: string;
  name: string;
  type: 'recurring_post' | 'budget_optimizer' | 'performance_alert' | 'ab_test' | 'caption_generator';
  config: Record<string, unknown>;
  enabled: boolean;
  last_run?: string;
  next_run?: string;
  created_at: string;
}

// ─── Market/Country Mapping ──────────────────────────────────────────────────

export const MARKETS: Record<string, { name: string; flag: string; location_id: string; timezone: string; best_hours: string }> = {
  GB: { name: 'Birleşik Krallık', flag: '🇬🇧', location_id: '905501', timezone: 'Europe/London', best_hours: '19:00–21:00 GMT' },
  US: { name: 'Amerika', flag: '🇺🇸', location_id: '905502', timezone: 'America/New_York', best_hours: '15:00–17:00 EST' },
  TR: { name: 'Türkiye', flag: '🇹🇷', location_id: '905503', timezone: 'Europe/Istanbul', best_hours: '20:00–22:00 TRT' },
  DE: { name: 'Almanya', flag: '🇩🇪', location_id: '905504', timezone: 'Europe/Berlin', best_hours: '18:00–20:00 CET' },
  FR: { name: 'Fransa', flag: '🇫🇷', location_id: '905505', timezone: 'Europe/Paris', best_hours: '18:00–20:00 CET' },
  AU: { name: 'Avustralya', flag: '🇦🇺', location_id: '905506', timezone: 'Australia/Sydney', best_hours: '19:00–21:00 AEST' },
};

// ─── Core API Client ─────────────────────────────────────────────────────────

class TikTokAPIClient {
  private accessToken: string;
  private advertiserId: string;

  constructor() {
    this.accessToken = process.env.TIKTOK_ACCESS_TOKEN || '';
    this.advertiserId = process.env.TIKTOK_ADVERTISER_ID || '';
  }

  private async adsRequest<T>(
    endpoint: string,
    method: 'GET' | 'POST' | 'DELETE' = 'GET',
    body?: Record<string, unknown>
  ): Promise<T> {
    const url = `${TIKTOK_ADS_BASE}${endpoint}`;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Access-Token': this.accessToken,
    };

    const res = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!res.ok) {
      throw new Error(`TikTok Ads API error: ${res.status} ${res.statusText}`);
    }

    const data = await res.json();
    if (data.code !== 0) {
      throw new Error(`TikTok API error ${data.code}: ${data.message}`);
    }
    return data.data as T;
  }

  // ── OAuth Flow ─────────────────────────────────────────────────────────────

  getAuthUrl(): string {
    const params = new URLSearchParams({
      app_id: process.env.TIKTOK_APP_ID || '',
      redirect_uri: process.env.TIKTOK_REDIRECT_URI || '',
      state: crypto.randomUUID(),
      scope: 'campaign.show,campaign.edit,report.show,video.show',
    });
    return `https://ads.tiktok.com/marketing_api/auth?${params}`;
  }

  async exchangeCode(code: string): Promise<{ access_token: string; advertiser_ids: string[] }> {
    const res = await fetch(`${TIKTOK_ADS_BASE}/oauth2/access_token/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        app_id: process.env.TIKTOK_APP_ID,
        secret: process.env.TIKTOK_APP_SECRET,
        auth_code: code,
      }),
    });
    const data = await res.json();
    return data.data;
  }

  // ── Campaigns ──────────────────────────────────────────────────────────────

  async getCampaigns(): Promise<TikTokCampaign[]> {
    const data = await this.adsRequest<{ list: TikTokCampaign[] }>(
      `/campaign/get/?advertiser_id=${this.advertiserId}&page_size=50`
    );
    return data.list;
  }

  async createCampaign(params: {
    name: string;
    objective: 'REACH' | 'TRAFFIC' | 'VIDEO_VIEWS' | 'CONVERSIONS' | 'APP_INSTALL';
    budget: number;
    budget_mode: 'BUDGET_MODE_DAY' | 'BUDGET_MODE_TOTAL';
  }): Promise<{ campaign_id: string }> {
    return this.adsRequest('/campaign/create/', 'POST', {
      advertiser_id: this.advertiserId,
      campaign_name: params.name,
      objective_type: params.objective,
      budget: params.budget,
      budget_mode: params.budget_mode,
    });
  }

  async updateCampaignStatus(
    campaignId: string,
    operation: 'ENABLE' | 'DISABLE' | 'DELETE'
  ): Promise<void> {
    await this.adsRequest('/campaign/status/update/', 'POST', {
      advertiser_id: this.advertiserId,
      campaign_ids: [campaignId],
      operation_status: operation,
    });
  }

  async updateCampaignBudget(campaignId: string, budget: number): Promise<void> {
    await this.adsRequest('/campaign/update/', 'POST', {
      advertiser_id: this.advertiserId,
      campaign_id: campaignId,
      budget,
    });
  }

  // ── Ad Groups ──────────────────────────────────────────────────────────────

  async createAdGroup(params: {
    campaign_id: string;
    name: string;
    markets: string[];
    budget: number;
    start_time: string;
    end_time?: string;
    age_groups?: string[];
    gender?: 'GENDER_MALE' | 'GENDER_FEMALE' | 'GENDER_UNLIMITED';
    interests?: string[];
  }): Promise<{ adgroup_id: string }> {
    const locationIds = params.markets.map(m => MARKETS[m]?.location_id).filter(Boolean);

    return this.adsRequest('/adgroup/create/', 'POST', {
      advertiser_id: this.advertiserId,
      campaign_id: params.campaign_id,
      adgroup_name: params.name,
      placement_type: 'PLACEMENT_TYPE_AUTOMATIC',
      budget: params.budget,
      budget_mode: 'BUDGET_MODE_DAY',
      schedule_type: 'SCHEDULE_START_END',
      schedule_start_time: params.start_time,
      schedule_end_time: params.end_time,
      location_ids: locationIds,
      gender: params.gender || 'GENDER_UNLIMITED',
      age: params.age_groups || ['AGE_25_34', 'AGE_35_44'],
      interest_category_ids: params.interests || [],
      billing_event: 'OCPM',
      optimization_goal: 'REACH',
    });
  }

  // ── Analytics / Reports ────────────────────────────────────────────────────

  async getCampaignMetrics(
    campaignIds: string[],
    dateRange: { start: string; end: string }
  ): Promise<CampaignMetrics[]> {
    const data = await this.adsRequest<{ list: CampaignMetrics[] }>(
      `/report/integrated/get/?advertiser_id=${this.advertiserId}`,
      'GET'
    );
    // In real impl, pass filter params via POST body
    void campaignIds; void dateRange;
    return data.list || [];
  }

  async getAccountOverview(): Promise<{
    spend_today: number;
    spend_month: number;
    impressions_today: number;
    clicks_today: number;
  }> {
    try {
      const data = await this.adsRequest<Record<string, number>>(
        `/advertiser/info/?advertiser_ids=["${this.advertiserId}"]`
      );
      return {
        spend_today: (data.spend_today as number) || 0,
        spend_month: (data.spend_month as number) || 0,
        impressions_today: (data.impressions_today as number) || 0,
        clicks_today: (data.clicks_today as number) || 0,
      };
    } catch {
      return { spend_today: 0, spend_month: 0, impressions_today: 0, clicks_today: 0 };
    }
  }

  // ── Video Upload & Content Posting ─────────────────────────────────────────

  async uploadVideo(videoBuffer: Buffer, fileName: string): Promise<{ video_id: string }> {
    const formData = new FormData();
    formData.append('advertiser_id', this.advertiserId);
    formData.append('video_file', new Blob([videoBuffer]), fileName);

    const res = await fetch(`${TIKTOK_ADS_BASE}/file/video/ad/upload/`, {
      method: 'POST',
      headers: { 'Access-Token': this.accessToken },
      body: formData,
    });
    const data = await res.json();
    return data.data;
  }

  async initVideoUpload(params: {
    video_size: number;
    chunk_size: number;
    total_chunk_count: number;
  }): Promise<{ upload_id: string }> {
    const res = await fetch(`${TIKTOK_CONTENT_BASE}/post/publish/video/init/`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        post_info: { privacy_level: 'SELF_ONLY', title: '', disable_duet: false, disable_comment: false, disable_stitch: false },
        source_info: { source: 'FILE_UPLOAD', video_size: params.video_size, chunk_size: params.chunk_size, total_chunk_count: params.total_chunk_count },
      }),
    });
    const data = await res.json();
    return data.data;
  }

  async publishPost(params: {
    caption: string;
    video_id?: string;
    privacy_level?: 'PUBLIC_TO_EVERYONE' | 'MUTUAL_FOLLOW_FRIENDS' | 'FOLLOWER_OF_CREATOR';
  }): Promise<{ publish_id: string }> {
    const res = await fetch(`${TIKTOK_CONTENT_BASE}/post/publish/content/init/`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        post_info: {
          title: params.caption,
          privacy_level: params.privacy_level || 'PUBLIC_TO_EVERYONE',
          disable_duet: false,
          disable_comment: false,
          disable_stitch: false,
        },
        source_info: {
          source: 'PULL_FROM_URL',
          video_url: params.video_id,
        },
      }),
    });
    const data = await res.json();
    return data.data;
  }
}

export const tiktokClient = new TikTokAPIClient();
export default TikTokAPIClient;
