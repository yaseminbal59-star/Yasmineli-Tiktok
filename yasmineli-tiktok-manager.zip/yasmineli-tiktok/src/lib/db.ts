// lib/db.ts
// Simple JSON file-based database — no external DB needed
// In production, swap to PostgreSQL / Supabase

import fs from 'fs';
import path from 'path';
import type { ScheduledPost, AutomationRule } from './tiktok-api';

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'yasmineli.json');

interface DB {
  campaigns: StoredCampaign[];
  scheduled_posts: ScheduledPost[];
  automation_rules: AutomationRule[];
  settings: AppSettings;
  last_updated: string;
}

export interface StoredCampaign {
  id: string;
  tiktok_campaign_id?: string;
  name: string;
  objective: string;
  ad_type: string;
  markets: string[];
  budget_daily: number;
  budget_total?: number;
  spend: number;
  impressions: number;
  clicks: number;
  conversions: number;
  ctr: number;
  status: 'active' | 'paused' | 'scheduled' | 'ended';
  start_date: string;
  end_date?: string;
  created_at: string;
}

export interface AppSettings {
  tiktok_connected: boolean;
  advertiser_id?: string;
  account_name?: string;
  default_markets: string[];
  currency: string;
  notification_email?: string;
  budget_alert_threshold: number;
}

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}

function readDB(): DB {
  ensureDataDir();
  if (!fs.existsSync(DB_FILE)) {
    const initial: DB = {
      campaigns: [
        {
          id: 'c1',
          name: 'UK Luxury Crib 2025',
          objective: 'REACH',
          ad_type: 'In-Feed Ads',
          markets: ['GB'],
          budget_daily: 200,
          spend: 4200,
          impressions: 84000,
          clicks: 2688,
          conversions: 42,
          ctr: 3.2,
          status: 'active',
          start_date: '2025-01-01',
          created_at: '2025-01-01T10:00:00Z',
        },
        {
          id: 'c2',
          name: 'US Babynest Launch',
          objective: 'CONVERSIONS',
          ad_type: 'TopView',
          markets: ['US'],
          budget_daily: 350,
          spend: 6800,
          impressions: 210000,
          clicks: 10710,
          conversions: 128,
          ctr: 5.1,
          status: 'active',
          start_date: '2025-01-15',
          created_at: '2025-01-15T10:00:00Z',
        },
        {
          id: 'c3',
          name: 'Global Roseline Collection',
          objective: 'TRAFFIC',
          ad_type: 'In-Feed Ads',
          markets: ['TR', 'GB', 'US', 'DE'],
          budget_daily: 150,
          spend: 2100,
          impressions: 62000,
          clicks: 2666,
          conversions: 31,
          ctr: 4.3,
          status: 'scheduled',
          start_date: '2025-03-20',
          created_at: '2025-03-10T10:00:00Z',
        },
      ],
      scheduled_posts: [
        {
          id: 'p1',
          title: 'Beşik Tanıtım',
          caption: '✨ Yasmineli luxury beşik koleksiyonu şimdi UK ve US\'de! #luxurybaby #yasmineli #crib',
          markets: ['GB', 'US'],
          scheduled_at: new Date().toISOString(),
          status: 'scheduled',
          created_at: new Date(Date.now() - 86400000).toISOString(),
        },
        {
          id: 'p2',
          title: 'Babynest Unboxing',
          caption: '👶 Babynest unboxing - the softest nest for your little one! #babynest #newborn #yasmineli',
          markets: ['US'],
          scheduled_at: new Date(Date.now() + 86400000).toISOString(),
          status: 'scheduled',
          created_at: new Date(Date.now() - 3600000).toISOString(),
        },
      ],
      automation_rules: [
        {
          id: 'a1',
          name: 'Haftalık Gönderi',
          type: 'recurring_post',
          config: { frequency: 'weekly', day: 'monday', time: '14:00', markets: ['GB', 'US'] },
          enabled: true,
          last_run: new Date(Date.now() - 2 * 86400000).toISOString(),
          next_run: new Date(Date.now() + 5 * 86400000).toISOString(),
          created_at: new Date().toISOString(),
        },
        {
          id: 'a2',
          name: 'Bütçe Optimizasyonu',
          type: 'budget_optimizer',
          config: { ctr_threshold: 3.0, action: 'redistribute' },
          enabled: true,
          last_run: new Date(Date.now() - 3 * 3600000).toISOString(),
          created_at: new Date().toISOString(),
        },
        {
          id: 'a3',
          name: 'Çok Dilli Caption',
          type: 'caption_generator',
          config: { markets: ['GB', 'US', 'DE'], ai_model: 'claude' },
          enabled: true,
          created_at: new Date().toISOString(),
        },
      ],
      settings: {
        tiktok_connected: false,
        default_markets: ['GB', 'US', 'TR'],
        currency: 'TRY',
        budget_alert_threshold: 80,
      },
      last_updated: new Date().toISOString(),
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2));
    return initial;
  }
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
}

function writeDB(data: DB) {
  ensureDataDir();
  data.last_updated = new Date().toISOString();
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

// ─── Campaign CRUD ────────────────────────────────────────────────────────────

export function getCampaigns(): StoredCampaign[] {
  return readDB().campaigns;
}

export function getCampaignById(id: string): StoredCampaign | undefined {
  return readDB().campaigns.find(c => c.id === id);
}

export function createCampaign(data: Omit<StoredCampaign, 'id' | 'created_at' | 'spend' | 'impressions' | 'clicks' | 'conversions' | 'ctr'>): StoredCampaign {
  const db = readDB();
  const campaign: StoredCampaign = {
    ...data,
    id: `c${Date.now()}`,
    spend: 0,
    impressions: 0,
    clicks: 0,
    conversions: 0,
    ctr: 0,
    created_at: new Date().toISOString(),
  };
  db.campaigns.push(campaign);
  writeDB(db);
  return campaign;
}

export function updateCampaign(id: string, updates: Partial<StoredCampaign>): StoredCampaign | null {
  const db = readDB();
  const idx = db.campaigns.findIndex(c => c.id === id);
  if (idx === -1) return null;
  db.campaigns[idx] = { ...db.campaigns[idx], ...updates };
  writeDB(db);
  return db.campaigns[idx];
}

export function deleteCampaign(id: string): boolean {
  const db = readDB();
  const len = db.campaigns.length;
  db.campaigns = db.campaigns.filter(c => c.id !== id);
  writeDB(db);
  return db.campaigns.length < len;
}

// ─── Scheduled Posts CRUD ─────────────────────────────────────────────────────

export function getScheduledPosts(): ScheduledPost[] {
  return readDB().scheduled_posts;
}

export function createScheduledPost(data: Omit<ScheduledPost, 'id' | 'created_at' | 'status'>): ScheduledPost {
  const db = readDB();
  const post: ScheduledPost = {
    ...data,
    id: `p${Date.now()}`,
    status: 'scheduled',
    created_at: new Date().toISOString(),
  };
  db.scheduled_posts.push(post);
  writeDB(db);
  return post;
}

export function updateScheduledPost(id: string, updates: Partial<ScheduledPost>): ScheduledPost | null {
  const db = readDB();
  const idx = db.scheduled_posts.findIndex(p => p.id === id);
  if (idx === -1) return null;
  db.scheduled_posts[idx] = { ...db.scheduled_posts[idx], ...updates };
  writeDB(db);
  return db.scheduled_posts[idx];
}

export function deleteScheduledPost(id: string): boolean {
  const db = readDB();
  const len = db.scheduled_posts.length;
  db.scheduled_posts = db.scheduled_posts.filter(p => p.id !== id);
  writeDB(db);
  return db.scheduled_posts.length < len;
}

// ─── Automation Rules CRUD ───────────────────────────────────────────────────

export function getAutomationRules(): AutomationRule[] {
  return readDB().automation_rules;
}

export function createAutomationRule(data: Omit<AutomationRule, 'id' | 'created_at'>): AutomationRule {
  const db = readDB();
  const rule: AutomationRule = {
    ...data,
    id: `a${Date.now()}`,
    created_at: new Date().toISOString(),
  };
  db.automation_rules.push(rule);
  writeDB(db);
  return rule;
}

export function updateAutomationRule(id: string, updates: Partial<AutomationRule>): AutomationRule | null {
  const db = readDB();
  const idx = db.automation_rules.findIndex(r => r.id === id);
  if (idx === -1) return null;
  db.automation_rules[idx] = { ...db.automation_rules[idx], ...updates };
  writeDB(db);
  return db.automation_rules[idx];
}

// ─── Settings ─────────────────────────────────────────────────────────────────

export function getSettings(): AppSettings {
  return readDB().settings;
}

export function updateSettings(updates: Partial<AppSettings>): AppSettings {
  const db = readDB();
  db.settings = { ...db.settings, ...updates };
  writeDB(db);
  return db.settings;
}

// ─── Dashboard Stats ──────────────────────────────────────────────────────────

export function getDashboardStats() {
  const db = readDB();
  const active = db.campaigns.filter(c => c.status === 'active');
  return {
    total_spend: db.campaigns.reduce((s, c) => s + c.spend, 0),
    total_impressions: db.campaigns.reduce((s, c) => s + c.impressions, 0),
    avg_ctr: active.length ? active.reduce((s, c) => s + c.ctr, 0) / active.length : 0,
    total_conversions: db.campaigns.reduce((s, c) => s + c.conversions, 0),
    active_campaigns: active.length,
    scheduled_posts: db.scheduled_posts.filter(p => p.status === 'scheduled').length,
    active_automations: db.automation_rules.filter(r => r.enabled).length,
  };
}
