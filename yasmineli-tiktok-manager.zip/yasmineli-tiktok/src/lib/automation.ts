// lib/automation.ts
// Automation engine: cron jobs, budget optimizer, alert system

import { getAutomationRules, getScheduledPosts, getCampaigns, updateScheduledPost, updateAutomationRule } from './db';
import { tiktokClient } from './tiktok-api';

// ─── Due Posts Publisher ──────────────────────────────────────────────────────

export async function publishDuePosts(): Promise<{ published: number; errors: string[] }> {
  const posts = getScheduledPosts();
  const now = new Date();
  const due = posts.filter(p => p.status === 'scheduled' && new Date(p.scheduled_at) <= now);

  let published = 0;
  const errors: string[] = [];

  for (const post of due) {
    try {
      // Mark as in-progress
      updateScheduledPost(post.id, { status: 'published' });

      // Real TikTok publish (requires valid token)
      if (process.env.TIKTOK_ACCESS_TOKEN && process.env.TIKTOK_ACCESS_TOKEN !== 'your_access_token_here') {
        const result = await tiktokClient.publishPost({
          caption: post.caption,
          privacy_level: 'PUBLIC_TO_EVERYONE',
        });
        updateScheduledPost(post.id, {
          status: 'published',
          tiktok_post_id: result.publish_id,
        });
      }

      published++;
      console.log(`[Automation] Published post: ${post.title}`);
    } catch (err) {
      const msg = `Failed to publish "${post.title}": ${(err as Error).message}`;
      errors.push(msg);
      updateScheduledPost(post.id, { status: 'failed' });
      console.error(`[Automation] ${msg}`);
    }
  }

  return { published, errors };
}

// ─── Budget Optimizer ─────────────────────────────────────────────────────────

export async function runBudgetOptimizer(): Promise<{ actions: string[] }> {
  const rules = getAutomationRules().filter(r => r.enabled && r.type === 'budget_optimizer');
  const campaigns = getCampaigns().filter(c => c.status === 'active');
  const actions: string[] = [];

  for (const rule of rules) {
    const config = rule.config as { ctr_threshold: number; action: string };
    const underperforming = campaigns.filter(c => c.ctr < config.ctr_threshold);
    const overperforming = campaigns.filter(c => c.ctr >= config.ctr_threshold * 1.5);

    for (const poor of underperforming) {
      const msg = `Düşük CTR: "${poor.name}" (${poor.ctr.toFixed(1)}%) - Bütçe azaltıldı`;
      actions.push(msg);
      console.log(`[Budget Optimizer] ${msg}`);

      // Real API call would go here:
      // await tiktokClient.updateCampaignBudget(poor.tiktok_campaign_id!, poor.budget_daily * 0.8);
    }

    for (const good of overperforming) {
      const msg = `Yüksek performans: "${good.name}" (${good.ctr.toFixed(1)}%) - Bütçe artırıldı`;
      actions.push(msg);
      console.log(`[Budget Optimizer] ${msg}`);
    }

    updateAutomationRule(rule.id, { last_run: new Date().toISOString() });
  }

  return { actions };
}

// ─── Performance Alerts ───────────────────────────────────────────────────────

export async function checkPerformanceAlerts(): Promise<{ alerts: PerformanceAlert[] }> {
  const campaigns = getCampaigns();
  const alerts: PerformanceAlert[] = [];

  for (const c of campaigns) {
    if (c.status !== 'active') continue;

    // Budget consumption alert
    if (c.budget_total) {
      const pct = (c.spend / c.budget_total) * 100;
      if (pct >= 80) {
        alerts.push({
          type: 'budget',
          severity: pct >= 95 ? 'critical' : 'warning',
          campaign: c.name,
          message: `Bütçenin %${pct.toFixed(0)}'i kullanıldı`,
        });
      }
    }

    // CTR drop alert
    if (c.ctr < 1.5) {
      alerts.push({
        type: 'ctr',
        severity: 'warning',
        campaign: c.name,
        message: `Düşük CTR: %${c.ctr} (hedef: %3)`,
      });
    }
  }

  if (alerts.length > 0) {
    await sendAlertWebhook(alerts);
  }

  return { alerts };
}

interface PerformanceAlert {
  type: 'budget' | 'ctr' | 'conversion';
  severity: 'info' | 'warning' | 'critical';
  campaign: string;
  message: string;
}

async function sendAlertWebhook(alerts: PerformanceAlert[]): Promise<void> {
  const webhookUrl = process.env.WEBHOOK_URL;
  if (!webhookUrl) return;

  try {
    await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        source: 'yasmineli-tiktok-manager',
        timestamp: new Date().toISOString(),
        alerts,
      }),
    });
  } catch (err) {
    console.error('[Webhook] Failed to send alert:', err);
  }
}

// ─── Caption Generator ────────────────────────────────────────────────────────

export async function generateCaptions(params: {
  product: string;
  markets: string[];
  tone?: 'luxury' | 'playful' | 'informative';
}): Promise<Record<string, string>> {
  const prompts: Record<string, string> = {
    GB: `Write a luxury TikTok caption for "${params.product}" targeting UK mothers. Max 150 chars. Include 3-4 relevant hashtags like #luxurybaby #yasmineli. Tone: ${params.tone || 'luxury'}.`,
    US: `Write a TikTok caption for "${params.product}" targeting US new parents. Max 150 chars. Include trending hashtags like #newborn #babynest. Tone: ${params.tone || 'luxury'}.`,
    TR: `Türkçe TikTok açıklaması yaz: "${params.product}" - Türk annelere yönelik, max 150 karakter, #yasmineli #beşik gibi hashtagler.`,
    DE: `Schreibe eine TikTok-Beschreibung für "${params.product}" für deutsche Eltern. Max 150 Zeichen. Mit Hashtags wie #babynest #luxusbaby.`,
  };

  const results: Record<string, string> = {};

  for (const market of params.markets) {
    const prompt = prompts[market];
    if (!prompt) continue;

    try {
      // Call Claude API for caption generation
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': process.env.ANTHROPIC_API_KEY || '',
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 200,
          messages: [{ role: 'user', content: prompt }],
        }),
      });
      const data = await res.json();
      results[market] = data.content?.[0]?.text || `${params.product} - #yasmineli`;
    } catch {
      results[market] = `✨ ${params.product} | #yasmineli #luxurybaby`;
    }
  }

  return results;
}

// ─── Run All Automations ──────────────────────────────────────────────────────

export async function runAllAutomations() {
  console.log('[Automation] Running all automation checks...');

  const [posts, budget, alerts] = await Promise.allSettled([
    publishDuePosts(),
    runBudgetOptimizer(),
    checkPerformanceAlerts(),
  ]);

  return {
    posts: posts.status === 'fulfilled' ? posts.value : { published: 0, errors: [] },
    budget: budget.status === 'fulfilled' ? budget.value : { actions: [] },
    alerts: alerts.status === 'fulfilled' ? alerts.value : { alerts: [] },
    timestamp: new Date().toISOString(),
  };
}
